CRASM is a portable cross-assembler for 6800/6801/6803/6502/65C02/Z80.

The ZIP file contains Version 1.5 of Leon Bottou's CRASM compiled for 32 Bit Windows.

Tested on Windows 7 64-Bit, Windows Vista 32-bit, & Windows XP.

Compiled using MinGW on Windows 7 by M. Edward Wilborne, III

e-mail: wilborne@mew3.com

Find the download here:  http://mew3.com/crasm/crasm15.zip

MinGW can be found here:

http://www.mingw.org/

The CRASM source code, etc. can be found here:

http://crasm.sourceforge.net/

README.txt v1.0, 2011-05-08